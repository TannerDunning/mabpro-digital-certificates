<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://sites.google.com/mabpro.com/custom-cert-plugin/
 * @since      1.0.0
 *
 * @package    Mabpro_Digital_Certificates
 * @subpackage Mabpro_Digital_Certificates/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
